# TenSyGrid $\LaTeX$ Package (under development)
This package provides a style definition for typesetting documents in TenSyGrid design guidelines.

## Table of Contents
* [Support](#support)
* [Usage](#usage)
  * [Partner Acronyms](#partner-acronyms)
## Support
The package currently only supports the following document classes:

+ [beamer (alpha state)](https://ctan.org/pkg/beamer) - LaTeX class for producing presentations and slides
+ [koma-script](https://ctan.org/pkg/koma-script) - A bundle of versatile classes and packages
  + [scrreprt (pre-alpha)](https://ctan.org/pkg/scrreprt) - Koma-Script "report" class
## Usage
This packages requires the `xelatex` $\LaTeX$ program that runs `xetex` $\TeX$ engine. This is because the regular `pdflatex` setup is not ideal for external font usage, i.e, the `Ralleway` font family for TenSyGrid.

### Partner Acronyms
The package contains predefined templates adapted to each TenSyGrid partner via an optional argument, e.g.,
```latex
\usepackage[IWES]{tensygrid}
```

A table with all the partner acronyms is given next:

| Acronym | Partner                                      |
|---------|----------------------------------------------|
| IWES    | Fraunhofer Institute for Wind Energy Systems |
| UPC     | Universitat Politècnica de Catalunya         |
| eRoots  | eRoots Analytics                             |
| HAW     | Hamburg University of Applied Sciences       |
| UM      | University of Malta                          |